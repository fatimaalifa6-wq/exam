---
name: OpenCV runtime
description: Environment-specific dependency behavior for the image-based OMR grader.
---

Use `opencv-python-headless` for the grader and ensure the Replit system dependencies include `libGL`. The package manager may temporarily install the graphical `opencv-python` alongside the headless package; verify that `cv2` imports and exposes its native image functions before running the app.

**Why:** In this environment, installing or repairing the headless package caused the graphical OpenCV wheel to appear, and `cv2` then failed on `libGL.so.1` or had an incomplete native module after removal.

**How to apply:** When dependencies are refreshed, check `import cv2` and a basic operation such as `cv2.circle`; keep `requirements.txt` aligned with the project's intended headless dependency list.