---
name: OMR photo robustness
description: Durable guidance for maintaining reliable grading of printed answer-sheet photos.
---

Use the printed corner markers as the primary perspective reference, with paper-edge detection only as a fallback. Measure bubble darkness against nearby paper brightness so shadows do not turn printed option letters into false marks.

**Why:** A global darkness threshold produced false multiple answers on a clean rasterized sheet and became unreliable under uneven lighting and perspective.

**How to apply:** Keep the four markers visible in the capture instructions, preserve a separate multiple-mark state, and validate changes against flat, tilted, shadowed, blank, and double-marked sheets.