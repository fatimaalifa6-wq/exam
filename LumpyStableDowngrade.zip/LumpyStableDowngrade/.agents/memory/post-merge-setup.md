---
name: Post-merge setup
description: How the Python post-merge hook behaves in this managed Replit environment.
---

The post-merge hook should validate the Python source and import the Flask app, but should not run `pip install`. Dependencies are managed by the Replit Python environment and direct pip installation fails under the externally managed Nix runtime.

**Why:** The first hook attempt failed with PEP 668 because pip tried to modify the immutable system environment.

**How to apply:** Keep the hook non-interactive and fast. If dependencies change, update the project dependency configuration through the supported package-management flow instead of installing them from the hook.