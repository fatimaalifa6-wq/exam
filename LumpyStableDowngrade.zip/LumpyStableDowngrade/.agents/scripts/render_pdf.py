from pathlib import Path
import sys

import fitz


source = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
    "attached_assets/exam_FB3B3BA3_1789777341238.pdf"
)
output_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(".agents/outputs/exam-pdf")
output_dir.mkdir(parents=True, exist_ok=True)

document = fitz.open(source)
print(f"pages={document.page_count}")
for index, page in enumerate(document):
    pixmap = page.get_pixmap(matrix=fitz.Matrix(2.5, 2.5), alpha=False)
    output = output_dir / f"page-{index + 1}.png"
    pixmap.save(output)
    print(output)