#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

PYTHON_BIN="${PYTHON_BIN:-python}"

test -f requirements.txt

"${PYTHON_BIN}" -m py_compile \
  main.py \
  app.py \
  exam_generator.py \
  omr_grader.py \
  omr_layout.py

"${PYTHON_BIN}" - <<'PY'
from app import app

assert app.url_map
print("post-merge validation ok")
PY